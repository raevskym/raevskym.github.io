library(shiny)

shinyUI(fluidPage(
  titlePanel("Identifying SMS spam using Bayesian Classification"),
  fluidRow(
    column(12,
           "This project investigates", withTags({a(href="http://www.dt.fee.unicamp.br/~tiago/smsspamcollection/", "a large dataset of SMSs")}), "in order to identify words most commonly associated with spam. The word clouds below demonstrate the most frequently occuring words in the whole dataset, spam subset, and non-spam subset, respectively."
    ),
    column(4,
           plotOutput('plot1'),
           sliderInput('startQuarter1', 'Minimum Word Frequency', min = 40, max = 50, value = 45)
    ),
    column(4,
           plotOutput('plot2'),
           sliderInput('startQuarter2', 'Minimum Word Frequency', min = 10, max = 20, value = 15)
    ),
    column(4,
           plotOutput('plot3'),
           sliderInput('startQuarter3', 'Minimum Word Frequency', min = 30, max = 40, value = 35)
    )
  )
))