library(shiny)

# data source: http://www.dt.fee.unicamp.br/~tiago/smsspamcollection/

sms <- read.csv("both.csv", stringsAsFactors = FALSE)
sms$type <- factor(sms$type)
spam <- read.csv("spam.csv", stringsAsFactors = FALSE)
spam$type <- factor(spam$type)
ham <- read.csv("ham.csv", stringsAsFactors = FALSE)
ham$type <- factor(ham$type)

install.packages("wordcloud")
library(wordcloud)

plot1<- function(startQuarter1) {
  wordcloud(sms$text, min.freq = startQuarter1, random.order = FALSE)
}
plot2<- function(startQuarter2) {
  wordcloud(spam$text, min.freq = startQuarter2, random.order = FALSE)
}
plot3<- function(startQuarter3) {
  wordcloud(ham$text, min.freq = startQuarter3, random.order = FALSE)
}


  
shinyServer(
  function(input, output) {
    output$plot1 <- renderPlot({plot1(input$startQuarter1)})
    output$plot2 <- renderPlot({plot2(input$startQuarter2)})
    output$plot3 <- renderPlot({plot3(input$startQuarter3)})
    }
  )